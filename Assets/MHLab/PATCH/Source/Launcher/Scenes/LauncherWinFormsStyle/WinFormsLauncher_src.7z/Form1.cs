﻿using System;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Reflection;
using MHLab.PATCH.Debugging;
using MHLab.PATCH.Settings;
using MHLab.PATCH.Utilities;
using MHLab.PATCH.Install;

namespace MHLab.PATCH.Launcher
{
    public partial class Form1 : Form
    {
        #region Private fields
        LauncherManager m_launcher;
        InstallManager m_installer;
        Thread checkUpdates;

        #endregion

        #region Constructors
        public Form1()
        {
            InitializeComponent();

            m_launcher = new LauncherManager();
            m_launcher.LoadSettings();
            m_launcher.SetOnSetMainProgressBarAction(OnSetMainProgressBar);
            m_launcher.SetOnSetDetailProgressBarAction(OnSetDetailProgressBar);
            m_launcher.SetOnIncreaseMainProgressBarAction(OnIncreaseMainProgressBar);
            m_launcher.SetOnIncreaseDetailProgressBarAction(OnIncreaseDetailProgressBar);
            m_launcher.SetOnLogAction(OnLog);
            m_launcher.SetOnErrorAction(OnError);
            m_launcher.SetOnFatalErrorAction(OnFatalError);
            m_launcher.SetOnTaskStartedAction(OnTaskStarted);
            m_launcher.SetOnTaskCompletedAction(OnTaskCompleted);
            m_launcher.SetOnDownloadProgressAction(OnDownloadProgress);
            m_launcher.SetOnDownloadCompletedAction(OnDownloadCompleted);

            m_installer = new InstallManager();
            m_installer.LoadSettings();
            m_installer.SetOnSetMainProgressBarAction(OnSetMainProgressBar);
            m_installer.SetOnSetDetailProgressBarAction(OnSetDetailProgressBar);
            m_installer.SetOnIncreaseMainProgressBarAction(OnIncreaseMainProgressBar);
            m_installer.SetOnIncreaseDetailProgressBarAction(OnIncreaseDetailProgressBar);
            m_installer.SetOnLogAction(OnLog);
            m_installer.SetOnErrorAction(OnError);
            m_installer.SetOnFatalErrorAction(OnFatalError);
            m_installer.SetOnTaskStartedAction(OnTaskStarted);
            m_installer.SetOnTaskCompletedAction(OnTaskCompleted);
            m_installer.SetOnDownloadProgressAction(OnDownloadProgress);
            m_installer.SetOnDownloadCompletedAction(OnDownloadCompleted);

            // Edit and uncomment this value to change size of download buffer, in byte
            SettingsManager.DOWNLOAD_BUFFER_SIZE = 8192;

            this.LauncherVersionLabel.Text += "v" + Assembly.GetExecutingAssembly().GetName().Version.ToString();
            this.CoreVersionLabel.Text += "v" + Utility.GetVersion();
            if(!m_installer.IsToInstall())
                this.currentBuildLabel.Text = "Build: v" + m_launcher.GetCurrentVersion();
            this.LaunchButton.Enabled = false;
        }
        #endregion

        #region Callbacks for New version
        void OnSetMainProgressBar(int min, int max)
        {
            this.MainProgressBar.BeginInvoke((MethodInvoker)delegate ()
            {
                this.MainProgressBar.Maximum = max;
                this.MainProgressBar.Minimum = min;
                this.MainProgressBar.Step = 1;

                this.MainProgressBar.Value = (min > 0) ? min : 0;
            });
        }

        void OnSetDetailProgressBar(int min, int max)
        {
            this.ProgressBar.BeginInvoke((MethodInvoker)delegate ()
            {
                this.ProgressBar.Maximum = max;
                this.ProgressBar.Minimum = min;
                this.ProgressBar.Step = 1;

                this.ProgressBar.Value = (min > 0) ? min : 0;
            });
        }

        void OnIncreaseMainProgressBar()
        {
            this.MainProgressBar.BeginInvoke((MethodInvoker)delegate ()
            {
                if(this.MainProgressBar.Value < this.MainProgressBar.Maximum)
                    this.MainProgressBar.PerformStep();
            });
        }

        void OnIncreaseDetailProgressBar()
        {
            this.ProgressBar.BeginInvoke((MethodInvoker)delegate ()
            {
                if (this.ProgressBar.Value < this.ProgressBar.Maximum)
                    this.ProgressBar.PerformStep();
            });
        }

        void OnLog(string main, string detail)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate ()
            {
                this.MainDebug.Text = main;
                this.DetailsDebug.Text = detail;
            });
        }

        void OnError(string main, string detail, Exception e)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate ()
            {
                this.MainDebug.Text = main;
                this.DetailsDebug.Text = detail;
                Debugger.Log(e.Message);
            });
        }

        void OnFatalError(string main, string detail, Exception e)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate ()
            {
                this.MainDebug.Text = main;
                this.DetailsDebug.Text = detail;
                Debugger.Log(e.Message);
                this.checkUpdates.Abort();
            });
        }

        void OnTaskStarted(string message)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate ()
            {
                this.MainDebug.Text = message;
                this.DetailsDebug.Text = "";
            });
        }

        void OnTaskCompleted(string message)
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate ()
            {
                this.currentBuildLabel.Text = "Build: v" + m_launcher.GetCurrentVersion();
                this.LaunchButton.Enabled = true;
                this.MainDebug.Text = message;
                this.DetailsDebug.Text = "";
            });
        }

        DateTime _lastTime = DateTime.UtcNow;
        long _lastSize = 0;
        int _downloadSpeed = 0;

        void OnDownloadProgress(long currentFileSize, long totalFileSize, int percentageCompleted)
        {
            if (_lastTime.AddSeconds(1) <= DateTime.UtcNow)
            {
                _downloadSpeed = (int)((currentFileSize - _lastSize) / (DateTime.UtcNow - _lastTime).TotalSeconds);
                _lastSize = currentFileSize;
                _lastTime = DateTime.UtcNow;
            }

            this.MainDebug.BeginInvoke((MethodInvoker)delegate ()
            {
                try
                {
                    this.ProgressBar.Value = percentageCompleted;
                }
                catch { }
                this.downloadProgressLabel.Text = percentageCompleted + "% - (" + Utility.FormatSizeBinary(currentFileSize, 2) + "/" + Utility.FormatSizeBinary(totalFileSize, 2) + ") @ " + Utility.FormatSizeBinary(_downloadSpeed, 2) + "/s";
            });
        }

        void OnDownloadCompleted()
        {
            this.MainDebug.BeginInvoke((MethodInvoker)delegate ()
            {
                this.downloadProgressLabel.Text = "";
            });
        }
        #endregion

        #region Private methods
        private void Form1_Shown(object sender, EventArgs e)
        {
            this.checkUpdates = new Thread(new ThreadStart(CheckForUpdates));
            this.checkUpdates.IsBackground = false;
            this.checkUpdates.Name = "Patch thread";
            this.checkUpdates.Start();
        }

        void CheckForUpdates()
        {
            if (!SettingsManager.INSTALL_IN_LOCAL_PATH)
            {
                SettingsManager.APP_PATH = m_installer.GetInstallationPath();
                SettingsManager.RegeneratePaths();
            }

            bool isToInstall = m_installer.IsToInstall();
            InstallationState installStatus;
            InstallationState installPatcherStatus;

            if (SettingsManager.ENABLE_INSTALLER)
            {
                if (isToInstall)
                {
                    installStatus = m_installer.Install();
                    
                    if (SettingsManager.INSTALL_PATCHER && installStatus == InstallationState.SUCCESS && !SettingsManager.INSTALL_IN_LOCAL_PATH)
                        installPatcherStatus = m_installer.InstallPatcher();
                    else
                        installPatcherStatus = InstallationState.SUCCESS;

                    if (SettingsManager.CREATE_DESKTOP_SHORTCUT && installStatus == InstallationState.SUCCESS && installPatcherStatus == InstallationState.SUCCESS && SettingsManager.INSTALL_PATCHER)
                    {
                        //Debugger.Log ("Shortcut creation linked to launcher");
                        m_installer.CreateShortcut();
                    }
                    else if (SettingsManager.CREATE_DESKTOP_SHORTCUT && (installPatcherStatus == InstallationState.FAILED || !SettingsManager.INSTALL_PATCHER))
                    {
                        //Debugger.Log ("Shortcut creation linked to game");
                        if(SettingsManager.ENABLE_PATCHER)
                            m_installer.CreateShortcut();
                        else
                            m_installer.CreateShortcut(false);
                    }
                }
            }

            if (SettingsManager.ENABLE_REPAIRER)
            {
                if (!isToInstall)
                {
                    m_installer.Repair();
                }
            }

            if (SettingsManager.ENABLE_PATCHER)
                CheckForPatches();

            if (!SettingsManager.INSTALL_IN_LOCAL_PATH)
            {
                SettingsManager.APP_PATH = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                SettingsManager.RegeneratePaths();
            }
        }

        void CheckForPatches()
        {
            m_launcher.CheckForUpdates();
        }


        private void LaunchButton_Click(object sender, EventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(SettingsManager.LAUNCH_APP, (SettingsManager.USE_RAW_LAUNCH_ARG) ? SettingsManager.LAUNCH_ARG : SettingsManager.LAUNCH_COMMAND);
                Application.Exit();
            }
            catch
            {
                Application.Exit();
            }
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void PatchForm_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        #endregion
    }
}

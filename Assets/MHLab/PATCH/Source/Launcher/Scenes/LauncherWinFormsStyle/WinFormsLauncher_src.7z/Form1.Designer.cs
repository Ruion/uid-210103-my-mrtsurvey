﻿namespace MHLab.PATCH.Launcher
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.MainDebug = new System.Windows.Forms.TextBox();
            this.DetailsDebug = new System.Windows.Forms.TextBox();
            this.LaunchButton = new System.Windows.Forms.Button();
            this.MainProgressBar = new System.Windows.Forms.ProgressBar();
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.LauncherVersionLabel = new System.Windows.Forms.Label();
            this.CoreVersionLabel = new System.Windows.Forms.Label();
            this.currentBuildLabel = new System.Windows.Forms.Label();
            this.CloseButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.downloadProgressLabel = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // MainDebug
            // 
            this.MainDebug.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(12)))), ((int)(((byte)(12)))));
            this.MainDebug.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MainDebug.Enabled = false;
            this.MainDebug.ForeColor = System.Drawing.Color.White;
            this.MainDebug.Location = new System.Drawing.Point(12, 173);
            this.MainDebug.Name = "MainDebug";
            this.MainDebug.Size = new System.Drawing.Size(643, 13);
            this.MainDebug.TabIndex = 2;
            // 
            // DetailsDebug
            // 
            this.DetailsDebug.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(12)))), ((int)(((byte)(12)))));
            this.DetailsDebug.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DetailsDebug.Enabled = false;
            this.DetailsDebug.ForeColor = System.Drawing.Color.White;
            this.DetailsDebug.Location = new System.Drawing.Point(12, 227);
            this.DetailsDebug.Name = "DetailsDebug";
            this.DetailsDebug.Size = new System.Drawing.Size(643, 13);
            this.DetailsDebug.TabIndex = 3;
            // 
            // LaunchButton
            // 
            this.LaunchButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.LaunchButton.FlatAppearance.BorderSize = 0;
            this.LaunchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LaunchButton.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LaunchButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.LaunchButton.Location = new System.Drawing.Point(122, 15);
            this.LaunchButton.Name = "LaunchButton";
            this.LaunchButton.Size = new System.Drawing.Size(434, 54);
            this.LaunchButton.TabIndex = 5;
            this.LaunchButton.Text = "LAUNCH!";
            this.LaunchButton.UseVisualStyleBackColor = false;
            this.LaunchButton.Click += new System.EventHandler(this.LaunchButton_Click);
            // 
            // MainProgressBar
            // 
            this.MainProgressBar.Location = new System.Drawing.Point(12, 192);
            this.MainProgressBar.Name = "MainProgressBar";
            this.MainProgressBar.Size = new System.Drawing.Size(643, 11);
            this.MainProgressBar.TabIndex = 8;
            // 
            // ProgressBar
            // 
            this.ProgressBar.Location = new System.Drawing.Point(12, 247);
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(643, 12);
            this.ProgressBar.TabIndex = 7;
            // 
            // LauncherVersionLabel
            // 
            this.LauncherVersionLabel.AutoSize = true;
            this.LauncherVersionLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.LauncherVersionLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.LauncherVersionLabel.Location = new System.Drawing.Point(11, 357);
            this.LauncherVersionLabel.Name = "LauncherVersionLabel";
            this.LauncherVersionLabel.Size = new System.Drawing.Size(95, 13);
            this.LauncherVersionLabel.TabIndex = 9;
            this.LauncherVersionLabel.Text = "Launcher version: ";
            // 
            // CoreVersionLabel
            // 
            this.CoreVersionLabel.AutoSize = true;
            this.CoreVersionLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.CoreVersionLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.CoreVersionLabel.Location = new System.Drawing.Point(217, 357);
            this.CoreVersionLabel.Name = "CoreVersionLabel";
            this.CoreVersionLabel.Size = new System.Drawing.Size(72, 13);
            this.CoreVersionLabel.TabIndex = 10;
            this.CoreVersionLabel.Text = "Core version: ";
            // 
            // currentBuildLabel
            // 
            this.currentBuildLabel.AutoSize = true;
            this.currentBuildLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.currentBuildLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.currentBuildLabel.Location = new System.Drawing.Point(558, 77);
            this.currentBuildLabel.Name = "currentBuildLabel";
            this.currentBuildLabel.Size = new System.Drawing.Size(36, 13);
            this.currentBuildLabel.TabIndex = 11;
            this.currentBuildLabel.Text = "Build: ";
            // 
            // CloseButton
            // 
            this.CloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.CloseButton.FlatAppearance.BorderSize = 0;
            this.CloseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.CloseButton.Location = new System.Drawing.Point(633, 7);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(22, 23);
            this.CloseButton.TabIndex = 12;
            this.CloseButton.Text = "X";
            this.CloseButton.UseVisualStyleBackColor = false;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 21);
            this.label1.TabIndex = 13;
            this.label1.Text = "P.A.T.C.H. - Launcher";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.panel1.Controls.Add(this.LaunchButton);
            this.panel1.Controls.Add(this.currentBuildLabel);
            this.panel1.Location = new System.Drawing.Point(-2, 280);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(674, 100);
            this.panel1.TabIndex = 14;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MHPatcher3LauncherWin.Properties.Resources.patch;
            this.pictureBox1.Location = new System.Drawing.Point(120, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(434, 107);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // downloadProgressLabel
            // 
            this.downloadProgressLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(12)))), ((int)(((byte)(12)))));
            this.downloadProgressLabel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.downloadProgressLabel.Enabled = false;
            this.downloadProgressLabel.ForeColor = System.Drawing.Color.White;
            this.downloadProgressLabel.Location = new System.Drawing.Point(458, 227);
            this.downloadProgressLabel.Name = "downloadProgressLabel";
            this.downloadProgressLabel.Size = new System.Drawing.Size(197, 13);
            this.downloadProgressLabel.TabIndex = 15;
            this.downloadProgressLabel.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(12)))), ((int)(((byte)(12)))));
            this.ClientSize = new System.Drawing.Size(667, 375);
            this.Controls.Add(this.downloadProgressLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.ProgressBar);
            this.Controls.Add(this.CoreVersionLabel);
            this.Controls.Add(this.LauncherVersionLabel);
            this.Controls.Add(this.MainProgressBar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.DetailsDebug);
            this.Controls.Add(this.MainDebug);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "P.A.T.C.H. - Launcher";
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PatchForm_MouseDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox MainDebug;
        private System.Windows.Forms.TextBox DetailsDebug;
        private System.Windows.Forms.Button LaunchButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        //private CustomControls.CustomProgressBar ProgressBar;
        //private CustomControls.CustomProgressBar MainProgressBar;
        private System.Windows.Forms.ProgressBar ProgressBar;
        private System.Windows.Forms.ProgressBar MainProgressBar;
        private System.Windows.Forms.Label LauncherVersionLabel;
        private System.Windows.Forms.Label CoreVersionLabel;
        private System.Windows.Forms.Label currentBuildLabel;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox downloadProgressLabel;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public enum GUIState
{
    NONE,
    COMMAND_LINE_CHECKING_FAILED
}

